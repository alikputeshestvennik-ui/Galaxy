package com.blackbox.offline;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class AskDiaryActivity extends Activity {
    private EditText queryInput;
    private TextView resultText;
    private Button copyBtn;
    private String searchOutput = "";
    private LocalAiEngine aiEngine;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        aiEngine = new LocalAiEngine(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 18);
        int padV = UI.dp(this, 20);
        root.setPadding(padH, padV, padH, padV);

        // Header
        root.addView(UI.createHeader(this, "Спросить дневник", "Смысловой анализ и ответы Qwen AI", true));

        // Search Card
        LinearLayout searchCard = UI.createCard(this);

        TextView labelSearch = new TextView(this);
        labelSearch.setText("ВОПРОС К ДНЕВНИКУ");
        labelSearch.setTextColor(UI.COLOR_TEXT_SUBTLE);
        labelSearch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        labelSearch.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        labelSearch.setPadding(0, 0, 0, UI.dp(this, 8));
        searchCard.addView(labelSearch);

        queryInput = UI.inputField(this, "Например: О чём мы договорились на встрече?");
        searchCard.addView(queryInput);

        Button searchBtn = UI.primaryButton(this, "Спросить автономный AI");
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.topMargin = UI.dp(this, 12);
        searchBtn.setOnClickListener(v -> askDiary());
        searchCard.addView(searchBtn, btnLp);

        LinearLayout.LayoutParams scLp = new LinearLayout.LayoutParams(-1, -2);
        scLp.bottomMargin = UI.dp(this, 16);
        root.addView(searchCard, scLp);

        // Results Card
        LinearLayout resCard = UI.createCard(this);
        resCard.setBackground(UI.shape(UI.COLOR_SURFACE, UI.COLOR_BORDER, 16, this));

        LinearLayout headRow = new LinearLayout(this);
        headRow.setOrientation(LinearLayout.HORIZONTAL);
        headRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView resLabel = new TextView(this);
        resLabel.setText("ОТВЕТ AI");
        resLabel.setTextColor(UI.COLOR_TEXT_ORANGE);
        resLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        resLabel.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        headRow.addView(resLabel);

        copyBtn = UI.secondaryButton(this, "Скопировать");
        copyBtn.setVisibility(Button.GONE);
        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(-2, -2);
        cpLp.leftMargin = UI.dp(this, 12);
        copyBtn.setOnClickListener(v -> {
            if (!searchOutput.isEmpty()) {
                UI.copyToClipboard(this, "Ответ дневника", searchOutput);
            }
        });
        headRow.addView(copyBtn);

        resCard.addView(headRow);

        resultText = new TextView(this);
        resultText.setText("Задайте любой вопрос по вашим аудиозаписям — AI найдёт суть и ответит на русском.");
        resultText.setTextColor(UI.COLOR_TEXT_MUTED);
        resultText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        resultText.setLineSpacing(UI.dp(this, 4), 1.0f);
        resultText.setPadding(0, UI.dp(this, 12), 0, 0);
        resCard.addView(resultText);

        root.addView(resCard);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void askDiary() {
        String question = queryInput.getText().toString().trim();
        if (question.isEmpty()) {
            resultText.setText("Введите вопрос для анализа.");
            resultText.setTextColor(UI.COLOR_TEXT_MUTED);
            copyBtn.setVisibility(Button.GONE);
            return;
        }

        StringBuilder contextBuilder = new StringBuilder();
        int count = 0;
        for (Entry e : new EntryStore(this).all()) {
            if (e.transcript != null && !e.transcript.trim().isEmpty()) {
                count++;
                contextBuilder.append("[").append(e.created).append("] ")
                              .append(e.important ? "★ ВАЖНО: " : "")
                              .append(e.transcript.trim())
                              .append("\n\n");
            }
        }

        if (count == 0) {
            searchOutput = "";
            resultText.setText("В дневнике пока нет расшифрованных записей для анализа.");
            resultText.setTextColor(UI.COLOR_TEXT_MUTED);
            copyBtn.setVisibility(Button.GONE);
        } else {
            searchOutput = aiEngine.answer(question, contextBuilder.toString());
            resultText.setText(searchOutput);
            resultText.setTextColor(UI.COLOR_TEXT_PRIMARY);
            copyBtn.setVisibility(Button.VISIBLE);
        }
    }
}
