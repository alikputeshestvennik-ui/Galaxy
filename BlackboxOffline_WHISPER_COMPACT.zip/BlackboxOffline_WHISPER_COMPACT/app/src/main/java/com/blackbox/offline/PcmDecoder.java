package com.blackbox.offline;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

/** Decodes local AAC/M4A recordings to mono 16 kHz float PCM for whisper.cpp. */
final class PcmDecoder {
 private PcmDecoder() {}
 static float[] decode16kMono(String path) throws Exception {
  MediaExtractor ex=new MediaExtractor(); ex.setDataSource(path); int track=-1;
  for(int i=0;i<ex.getTrackCount();i++){MediaFormat f=ex.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("audio/")){track=i;break;}}
  if(track<0)throw new IllegalArgumentException("В записи нет аудиодорожки");
  ex.selectTrack(track); MediaFormat in=ex.getTrackFormat(track); String mime=in.getString(MediaFormat.KEY_MIME);
  MediaCodec codec=MediaCodec.createDecoderByType(mime); codec.configure(in,null,null,0); codec.start();
  int srcRate=in.containsKey(MediaFormat.KEY_SAMPLE_RATE)?in.getInteger(MediaFormat.KEY_SAMPLE_RATE):44100;
  int srcChannels=in.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?in.getInteger(MediaFormat.KEY_CHANNEL_COUNT):1;
  ArrayList<Float> mono=new ArrayList<>(); MediaCodec.BufferInfo info=new MediaCodec.BufferInfo(); boolean inputDone=false,outputDone=false;
  while(!outputDone){
   if(!inputDone){int idx=codec.dequeueInputBuffer(10000);if(idx>=0){ByteBuffer b=codec.getInputBuffer(idx);int n=ex.readSampleData(b,0);if(n<0){codec.queueInputBuffer(idx,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}else{codec.queueInputBuffer(idx,0,n,ex.getSampleTime(),0);ex.advance();}}}
   int out=codec.dequeueOutputBuffer(info,10000);if(out>=0){ByteBuffer b=codec.getOutputBuffer(out);if(b!=null&&info.size>0){b.position(info.offset);b.limit(info.offset+info.size);b.order(ByteOrder.LITTLE_ENDIAN);while(b.remaining()>=2){float total=0;int got=0;for(int c=0;c<srcChannels&&b.remaining()>=2;c++){total+=b.getShort()/32768f;got++;}if(got>0)mono.add(total/got);}}codec.releaseOutputBuffer(out,false);if((info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0)outputDone=true;}
  }
  codec.stop();codec.release();ex.release(); if(mono.isEmpty())throw new IllegalStateException("Не удалось декодировать аудио");
  int outCount=(int)((long)mono.size()*16000/srcRate);float[] out=new float[outCount];for(int i=0;i<outCount;i++){double p=(double)i*srcRate/16000;int a=(int)p,b=Math.min(a+1,mono.size()-1);double k=p-a;out[i]=(float)(mono.get(a)*(1-k)+mono.get(b)*k);}return out;
 }
}
