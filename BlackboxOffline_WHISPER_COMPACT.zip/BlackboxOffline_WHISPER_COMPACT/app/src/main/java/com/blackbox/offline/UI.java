package com.blackbox.offline;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Pure Luxury Obsidian & Signature Orange UI System.
 * Clean, minimalistic, devoid of unnecessary tiny tags or distracting noise.
 */
public final class UI {
    public static final int COLOR_BG = 0xFF0A0B0E;
    public static final int COLOR_SURFACE = 0xFF13161B;
    public static final int COLOR_SURFACE_ELEVATED = 0xFF191D24;
    public static final int COLOR_BORDER = 0xFF222832;

    public static final int COLOR_ORANGE = 0xFFF47721;
    public static final int COLOR_ORANGE_LIGHT = 0xFFFF8D3A;
    public static final int COLOR_ORANGE_DIM = 0x22F47721;
    public static final int COLOR_ORANGE_BORDER = 0xFF66300C;

    public static final int COLOR_IMPORTANT_BG = 0xFF1E140B;
    public static final int COLOR_IMPORTANT_BORDER = 0xFFA34D0F;

    public static final int COLOR_TEXT_TITLE = 0xFFFFFFFF;
    public static final int COLOR_TEXT_PRIMARY = 0xFFEDEDF0;
    public static final int COLOR_TEXT_MUTED = 0xFF8E95A2;
    public static final int COLOR_TEXT_SUBTLE = 0xFF585F6B;
    public static final int COLOR_TEXT_ORANGE = 0xFFFFA05C;

    public static final int COLOR_GREEN = 0xFF22C55E;
    public static final int COLOR_GREEN_BG = 0x2222C55E;
    public static final int COLOR_RED = 0xFFEF4444;

    private UI() {}

    public static int dp(Context c, int val) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, val, c.getResources().getDisplayMetrics());
    }

    public static GradientDrawable shape(int bgColor, int borderColor, int radiusDp, Context c) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(dp(c, radiusDp));
        if (borderColor != 0) {
            gd.setStroke(dp(c, 1), borderColor);
        }
        return gd;
    }

    public static GradientDrawable gradient(int startColor, int endColor, int radiusDp, Context c) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{startColor, endColor});
        gd.setCornerRadius(dp(c, radiusDp));
        return gd;
    }

    public static RippleDrawable buttonRipple(GradientDrawable content, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
    }

    public static LinearLayout createHeader(Activity a, String title, String subtitle, boolean showBack) {
        Context c = a;
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setPadding(0, 0, 0, dp(c, 16));

        if (showBack) {
            TextView back = new TextView(c);
            back.setText("‹ Назад");
            back.setTextColor(COLOR_ORANGE);
            back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            back.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            back.setPadding(0, dp(c, 4), dp(c, 16), dp(c, 8));
            back.setOnClickListener(v -> a.finish());
            bar.addView(back);
        }

        // Title row with Brand Mark
        LinearLayout titleRow = new LinearLayout(c);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView mark = new ImageView(c);
        int resId = c.getResources().getIdentifier("blackbox_mark", "drawable", c.getPackageName());
        if (resId != 0) mark.setImageResource(resId);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(c, 40), dp(c, 40));
        mlp.rightMargin = dp(c, 14);
        titleRow.addView(mark, mlp);

        LinearLayout textCol = new LinearLayout(c);
        textCol.setOrientation(LinearLayout.VERTICAL);

        TextView tvTitle = new TextView(c);
        tvTitle.setText(title);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tvTitle.setTextColor(COLOR_TEXT_TITLE);
        tvTitle.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        textCol.addView(tvTitle);

        if (subtitle != null && !subtitle.isEmpty()) {
            TextView tvSub = new TextView(c);
            tvSub.setText(subtitle);
            tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            tvSub.setTextColor(COLOR_TEXT_MUTED);
            tvSub.setPadding(0, dp(c, 2), 0, 0);
            textCol.addView(tvSub);
        }

        titleRow.addView(textCol);
        bar.addView(titleRow);

        return bar;
    }

    public static LinearLayout createCard(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(c, 18);
        l.setPadding(pad, pad, pad, pad);
        l.setBackground(shape(COLOR_SURFACE, COLOR_BORDER, 16, c));
        return l;
    }

    public static LinearLayout createImportantCard(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(c, 18);
        l.setPadding(pad, pad, pad, pad);
        l.setBackground(shape(COLOR_IMPORTANT_BG, COLOR_IMPORTANT_BORDER, 16, c));
        return l;
    }

    public static Button primaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setAllCaps(false);
        b.setBackground(buttonRipple(gradient(COLOR_ORANGE, COLOR_ORANGE_LIGHT, 14, c), 0x55FFFFFF));
        int padH = dp(c, 20);
        int padV = dp(c, 14);
        b.setPadding(padH, padV, padH, padV);
        return b;
    }

    public static Button secondaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(COLOR_TEXT_PRIMARY);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setAllCaps(false);
        b.setBackground(buttonRipple(shape(COLOR_SURFACE_ELEVATED, COLOR_BORDER, 12, c), 0x33F47721));
        int padH = dp(c, 16);
        int padV = dp(c, 12);
        b.setPadding(padH, padV, padH, padV);
        return b;
    }

    public static LinearLayout navCardButton(Context c, String drawableName, String title, String subtitle, View.OnClickListener onClick) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int padH = dp(c, 16);
        int padV = dp(c, 15);
        row.setPadding(padH, padV, padH, padV);
        row.setBackground(buttonRipple(shape(COLOR_SURFACE, COLOR_BORDER, 16, c), 0x33F47721));

        ImageView iconView = new ImageView(c);
        int iconRes = c.getResources().getIdentifier(drawableName, "drawable", c.getPackageName());
        if (iconRes != 0) {
            iconView.setImageResource(iconRes);
        }
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(c, 28), dp(c, 28));
        ip.rightMargin = dp(c, 14);
        row.addView(iconView, ip);

        LinearLayout textCol = new LinearLayout(c);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        textCol.setLayoutParams(lp);

        TextView tvTitle = new TextView(c);
        tvTitle.setText(title);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvTitle.setTextColor(COLOR_TEXT_PRIMARY);
        tvTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        textCol.addView(tvTitle);

        if (subtitle != null && !subtitle.isEmpty()) {
            TextView tvSub = new TextView(c);
            tvSub.setText(subtitle);
            tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvSub.setTextColor(COLOR_TEXT_MUTED);
            tvSub.setPadding(0, dp(c, 2), 0, 0);
            textCol.addView(tvSub);
        }
        row.addView(textCol);

        TextView chevron = new TextView(c);
        chevron.setText("›");
        chevron.setTextColor(COLOR_ORANGE);
        chevron.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        chevron.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        chevron.setPadding(dp(c, 6), 0, 0, 0);
        row.addView(chevron);

        row.setOnClickListener(onClick);
        return row;
    }

    public static TextView badge(Context c, String text, int textColor, int bgColor) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(textColor);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        int padH = dp(c, 8);
        int padV = dp(c, 3);
        tv.setPadding(padH, padV, padH, padV);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(dp(c, 6));
        tv.setBackground(gd);
        return tv;
    }

    public static EditText inputField(Context c, String hint) {
        EditText et = new EditText(c);
        et.setHint(hint);
        et.setHintTextColor(COLOR_TEXT_SUBTLE);
        et.setTextColor(COLOR_TEXT_PRIMARY);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        et.setBackground(shape(0xFF0F1116, 0xFF262C36, 12, c));
        int pad = dp(c, 14);
        et.setPadding(pad, pad, pad, pad);
        return et;
    }

    public static void copyToClipboard(Context c, String label, String text) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText(label, text));
            Toast.makeText(c, "Скопировано в буфер", Toast.LENGTH_SHORT).show();
        }
    }
}
