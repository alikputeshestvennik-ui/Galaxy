package com.blackbox.offline.wear;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class WatchMainActivity extends Activity {
    private static final int PERM_REQ = 77;

    // Modes: true = record on watch wrist microphone; false = remote control phone mic
    private boolean isWatchMicMode = true;

    private TextView titleText;
    private TextView modeChip;
    private ImageButton mainActionBtn;
    private TextView timerText;
    private TextView statusText;

    private boolean isRecording = false;
    private long recordStartMs = 0;
    private final Handler timerHandler = new Handler(Looper.getMainLooper());

    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (isRecording) {
                long elapsed = (System.currentTimeMillis() - recordStartMs) / 1000;
                long mins = elapsed / 60;
                long secs = elapsed % 60;
                timerText.setText(String.format(java.util.Locale.US, "%02d:%02d", mins, secs));
                timerHandler.postDelayed(this, 500);
            }
        }
    };

    private final BroadcastReceiver watchStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String action = i.getAction();
            if (WatchRecordingService.ACTION_STATE.equals(action)) {
                boolean active = i.getBooleanExtra("recording", false);
                setRecordingState(active);
            } else if (WatchTransferManager.ACTION_TRANSFER_STATUS.equals(action)) {
                String st = i.getStringExtra("status");
                if (st != null && statusText != null) {
                    statusText.setText(st);
                }
            } else if (WatchWearableListenerService.ACTION_PHONE_STATE.equals(action)) {
                boolean phoneActive = i.getBooleanExtra("active", false);
                if (!isWatchMicMode) {
                    setRecordingState(phoneActive);
                }
            } else if (WatchWearableListenerService.ACTION_TRANSCRIPT_RESULT.equals(action)) {
                String msg = i.getStringExtra("message");
                if (msg != null && statusText != null) {
                    statusText.setText(msg);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Keep ambient screen on while in app
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        renderRoundLayout();

        IntentFilter filter = new IntentFilter();
        filter.addAction(WatchRecordingService.ACTION_STATE);
        filter.addAction(WatchTransferManager.ACTION_TRANSFER_STATUS);
        filter.addAction(WatchWearableListenerService.ACTION_PHONE_STATE);
        filter.addAction(WatchWearableListenerService.ACTION_TRANSCRIPT_RESULT);

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(watchStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(watchStateReceiver, filter);
        }

        // Query initial phone state
        WatchTransferManager.queryPhoneState(this);
    }

    private void renderRoundLayout() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000); // True AMOLED black

        // Center content layout for circular display (Galaxy Watch 8 340-450 dpi)
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER_HORIZONTAL);
        int padH = dp(16);
        int padV = dp(18);
        center.setPadding(padH, padV, padH, padV);

        // 1. Top Logo + App Title
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView mark = new ImageView(this);
        int logoRes = getResources().getIdentifier("blackbox_mark", "drawable", getPackageName());
        if (logoRes != 0) mark.setImageResource(logoRes);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(22), dp(22));
        mlp.rightMargin = dp(6);
        topRow.addView(mark, mlp);

        titleText = new TextView(this);
        titleText.setText("BLACKBOX");
        titleText.setTextColor(Color.WHITE);
        titleText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        titleText.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        topRow.addView(titleText);

        center.addView(topRow);

        // 2. Mode Toggle Chip (Wrist Mic vs Phone Mic)
        modeChip = new TextView(this);
        updateModeChipText();
        modeChip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        modeChip.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        int cPadH = dp(8);
        int cPadV = dp(3);
        modeChip.setPadding(cPadH, cPadV, cPadH, cPadV);
        modeChip.setBackground(createChipBg(0xFF181C24, 0xFF28303E));
        modeChip.setOnClickListener(v -> {
            if (!isRecording) {
                isWatchMicMode = !isWatchMicMode;
                updateModeChipText();
            } else {
                Toast.makeText(this, "Сначала остановите текущую запись", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
        clp.topMargin = dp(4);
        clp.bottomMargin = dp(6);
        center.addView(modeChip, clp);

        // 3. Central Glowing Record / Stop Button (74 x 74 dp)
        mainActionBtn = new ImageButton(this);
        int btnSize = dp(74);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(btnSize, btnSize);
        blp.topMargin = dp(2);
        blp.bottomMargin = dp(6);
        mainActionBtn.setLayoutParams(blp);
        updateButtonVisuals(false);

        mainActionBtn.setOnClickListener(v -> onButtonClicked());
        center.addView(mainActionBtn);

        // 4. Timer / Status
        timerText = new TextView(this);
        timerText.setText("00:00");
        timerText.setTextColor(Color.WHITE);
        timerText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        timerText.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        timerText.setVisibility(View.GONE);
        center.addView(timerText);

        statusText = new TextView(this);
        statusText.setText("Нажмите для записи");
        statusText.setTextColor(0xFF8E95A2);
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        statusText.setGravity(Gravity.CENTER);
        statusText.setMaxLines(2);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.topMargin = dp(2);
        center.addView(statusText, slp);

        FrameLayout.LayoutParams rootLp = new FrameLayout.LayoutParams(-1, -1);
        rootLp.gravity = Gravity.CENTER;
        root.addView(center, rootLp);

        setContentView(root);
    }

    private void updateModeChipText() {
        if (isWatchMicMode) {
            modeChip.setText("⌚ Микрофон: ЧАСЫ");
            modeChip.setTextColor(0xFFFFA05C);
        } else {
            modeChip.setText("📱 Микрофон: ТЕЛЕФОН");
            modeChip.setTextColor(0xFF8E95A2);
        }
    }

    private void onButtonClicked() {
        if (isWatchMicMode) {
            // Local wrist mic recording on Galaxy Watch
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, PERM_REQ);
                return;
            }

            Intent serviceIntent = new Intent(this, WatchRecordingService.class);
            if (isRecording) {
                serviceIntent.setAction(WatchRecordingService.ACTION_STOP);
                startService(serviceIntent);
            } else {
                serviceIntent.setAction(WatchRecordingService.ACTION_START);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
            }
        } else {
            // Remote control smartphone mic
            WatchTransferManager.togglePhoneRecording(this);
            statusText.setText("Команда на смартфон...");
        }
    }

    private void setRecordingState(boolean active) {
        this.isRecording = active;
        updateButtonVisuals(active);

        if (active) {
            recordStartMs = System.currentTimeMillis();
            timerText.setVisibility(View.VISIBLE);
            timerHandler.post(timerRunnable);
            statusText.setText(isWatchMicMode ? "● Слушаю на запястье..." : "● Телефон пишет...");
            statusText.setTextColor(0xFFEF4444);
        } else {
            timerHandler.removeCallbacks(timerRunnable);
            timerText.setVisibility(View.GONE);
            statusText.setText("Нажмите для записи");
            statusText.setTextColor(0xFF8E95A2);
        }
    }

    private void updateButtonVisuals(boolean recording) {
        int bgRes = recording
                ? getResources().getIdentifier("btn_watch_record_active", "drawable", getPackageName())
                : getResources().getIdentifier("btn_watch_record_idle", "drawable", getPackageName());

        int iconRes = recording
                ? getResources().getIdentifier("ic_stop", "drawable", getPackageName())
                : getResources().getIdentifier("ic_mic", "drawable", getPackageName());

        if (bgRes != 0) mainActionBtn.setBackgroundResource(bgRes);
        if (iconRes != 0) mainActionBtn.setImageResource(iconRes);
    }

    private GradientDrawable createChipBg(int bg, int stroke) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bg);
        gd.setCornerRadius(dp(10));
        gd.setStroke(dp(1), stroke);
        return gd;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == PERM_REQ && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
            onButtonClicked();
        } else {
            Toast.makeText(this, "Нужен доступ к микрофону часов", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        timerHandler.removeCallbacks(timerRunnable);
        try {
            unregisterReceiver(watchStateReceiver);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
